
import React from 'react';
import TabManager from './TabManager';

const TabBar: React.FC = () => {
  return <TabManager />;
};

export default TabBar;
